ffplay -fflags nobuffer -flags low_delay -framedrop -max_delay 0 -analyzeduration 0 -probesize 32 -rtsp_transport udp -vf hflip,vflip rtsp://192.168.4.34:8554/cam
