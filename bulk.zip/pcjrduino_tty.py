#!/usr/bin/env python3
"""PCjr keyboard driver – sends press/release scancodes over serial."""
import sys, tty, termios, serial, select, time

SERIAL = '/dev/ttyACM0'
BAUD = 600

SCAN = {
    'a':0x1E,'b':0x30,'c':0x2E,'d':0x20,'e':0x12,'f':0x21,'g':0x22,
    'h':0x23,'i':0x17,'j':0x24,'k':0x25,'l':0x26,'m':0x32,'n':0x31,
    'o':0x18,'p':0x19,'q':0x10,'r':0x13,'s':0x1F,'t':0x14,'u':0x16,
    'v':0x2F,'w':0x11,'x':0x2D,'y':0x15,'z':0x2C,
    '0':0x0B,'1':0x02,'2':0x03,'3':0x04,'4':0x05,'5':0x06,'6':0x07,
    '7':0x08,'8':0x09,'9':0x0A,
    ' ':0x39,'-':0x0C,'=':0x0D,'[':0x1A,']':0x1B,';':0x27,"'":0x28,
    '`':0x29,'\\':0x2B,',':0x33,'.':0x34,'/':0x35,
    '\n':0x1C,'\r':0x1C,'\t':0x0F,'\b':0x0E,'\x1b':0x01,
}

SHIFT = {
    '!':'1','@':'2','#':'3','$':'4','%':'5','^':'6','&':'7','*':'8',
    '(':'9',')':'0','_':'-','+':'=','{':'[','}':']',':':';','"':"'",
    '~':'`','<':',','>':'.','?':'/','|':'\\',
}

ESC_MAP = {
    b'\x1b[A':0x48,b'\x1b[B':0x50,b'\x1b[C':0x4D,b'\x1b[D':0x4B,
    b'\x1b[H':0x47,b'\x1b[F':0x4F,b'\x1b[5~':0x49,b'\x1b[6~':0x51,
    b'\x1b[2~':0x52,b'\x1b[3~':0x53,
    b'\x1bOP':0x3B,b'\x1bOQ':0x3C,b'\x1bOR':0x3D,b'\x1bOS':0x3E,
    b'\x1b[15~':0x3F,b'\x1b[17~':0x40,b'\x1b[18~':0x41,b'\x1b[19~':0x42,
    b'\x1b[20~':0x43,b'\x1b[21~':0x44,b'\x1b[23~':0x57,b'\x1b[24~':0x58,
}

def send_code(ser, scan, mod=0):
    """Send modifier down, key press+release, modifier up (if mod)."""
    if mod:
        ser.write(bytes([mod]))
    ser.write(bytes([scan, scan | 0x80]))
    if mod:
        ser.write(bytes([mod | 0x80]))

def main():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    tty.setraw(fd)

    try:
        with serial.Serial(SERIAL, BAUD, timeout=0) as ser:
            esc_buf = b''
            last_esc = 0
            hex_mode = False
            hex_buf = ''

            def flush_esc_timeout(now):
                nonlocal esc_buf
                if esc_buf and (now - last_esc > 0.05):
                    send_code(ser, SCAN['\x1b'])
                    esc_buf = b''

            def handle_hex(ch):
                nonlocal hex_mode, hex_buf
                if ch in '0123456789abcdefABCDEF':
                    hex_buf += ch
                    if len(hex_buf) == 2:
                        send_code(ser, int(hex_buf, 16))
                        hex_mode = False
                        hex_buf = ''
                    return True
                else:
                    hex_mode = False
                    hex_buf = ''
                    return False

            def handle_escape(ch):
                nonlocal esc_buf, last_esc
                if not esc_buf:
                    esc_buf = b'\x1b'
                else:
                    esc_buf += ch.encode()
                last_esc = time.time()

                if esc_buf in ESC_MAP:
                    send_code(ser, ESC_MAP[esc_buf])
                    esc_buf = b''
                elif len(esc_buf) > 8:
                    esc_buf = b''   # discard junk

            def handle_regular(ch):
                b = ord(ch)
                if ch in SCAN:
                    send_code(ser, SCAN[ch])
                elif ch.isupper() and ch.lower() in SCAN:
                    send_code(ser, SCAN[ch.lower()], 0x2A)
                elif ch in SHIFT and SHIFT[ch] in SCAN:
                    send_code(ser, SCAN[SHIFT[ch]], 0x2A)
                elif 0x01 <= b <= 0x1A:
                    letter = chr(b + 0x60)
                    if letter in SCAN:
                        send_code(ser, SCAN[letter], 0x1D)

            # --- Main loop ---
            while True:
                now = time.time()
                flush_esc_timeout(now)

                r, _, _ = select.select([sys.stdin], [], [], 0.05)
                if not r:
                    continue

                ch = sys.stdin.read(1)
                if not ch:
                    break

                # Raw hex scancode entry (Ctrl+\ xx)
                if hex_mode:
                    if handle_hex(ch):
                        continue
                    # fall through: invalid hex char -> process normally

                # Toggle hex entry on Ctrl+\ (0x1C)
                if ch == '\x1c':
                    hex_mode = True
                    continue

                # Escape sequence
                if ch == '\x1b' or esc_buf:
                    handle_escape(ch)
                    continue

                # Regular character
                handle_regular(ch)

    except KeyboardInterrupt:
        pass
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        print(file=sys.stderr)

if __name__ == '__main__':
    main()
