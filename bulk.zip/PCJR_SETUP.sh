install() {
	echo "Basic updating"
	sudo apt update -y && sudo apt upgrade -y

	echo "Installing helpers"
	sudo apt install -y vim git avrdude
	git clone https://github.com/jblang/pcjr_type

	echo "Installing arduino-cli"
	curl -fsSL https://raw.githubusercontent/arduino/arduino-cli/master/install.sh | sh
	sudo chmod +x build/arduino-cli
	sudo mv bin/arduino-cli /usr/locals/bin
	rmdir bin
}

compile_and_upload() {
	echo "Compiling"
	sudo arduino-cli compile --fqbn arduino:avr:mega pcjr_type/ --build-path ./build

	echo "Uploading"
	sudo avrdude -v -p atmega2560 -c wiring -P /dev/ttyACM0 -b 115200 -D -U flash:w:build/pcjr_type.ino.hex
}

stream() {
	echo "Run this on watching pc:"
	echo "ffplay udp://@:5000 -fflags nobuffer -flags low_delay -framedrop -loglevel quiet"
	rpicam-vid -t 0 -n --inline -o udp://192.168.4.36:5000 --verbose=0
}

configure() {
	echo "Configure arduino-cli"
	sudo arduino-cli config init
	sudo arduino-cli core update-index
	sudo arduino-cli core install arduino:avr
}

all() {
	install
	compile_and_upload
}

use_component() {
	case $1 in
		"all")
			all
			;;
		"install")
			install
			;;

		"cu")
			compile_and_upload
			;;
	esac
}

if [[ $# > 0 ]]; then
	echo "Using partial: $1"
	use_component $1
	exit
else
	echo "Using all"
	all
fi
