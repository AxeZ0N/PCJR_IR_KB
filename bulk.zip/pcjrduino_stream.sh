mpv \
	--profile=low-latency\
	--cache=yes\
	--demuxer-lavf-o=rtsp_transport=tcp \
	rtsp://192.168.4.34:8554/cam

# Pi stream w/ audio (needs mic)
#mpv \
#	--ao=pulse\
#	--profile=low-latency\
#	--cache=yes\
#	--lavfi-complex="
#		[aid1] asplit [ao][a1];\
#		[a1] bandpass=f=3450:w=200,volume=20dB,
#				showvolume=r=10:w=900:h=600:f=0.1:
#				m=p:p=0.1:v=false:t=false, \
#				format=rgba [beep];
#		[vid1] [beep] overlay=W-w-12:H-h-12:format=auto [vo];
#		" \
#	--demuxer-lavf-o=rtsp_transport=tcp rtsp://192.168.4.34:8554/cam \
#	--volume=10

