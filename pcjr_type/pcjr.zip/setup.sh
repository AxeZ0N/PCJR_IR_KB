sudo apt update -y && sudo apt upgrade -y
sudo apt install vim ffmpeg
sudo systemctl enable --now pigpiod.service
curl -L -O https://github.com/bluenviron/mediamtx/releases/download/v1.19.2/mediamtx_v1.19.2_linux_armv6.tar.gz
tar -xvf mediamtx_v1.19.2_linux_armv6.tar.gz

#hlsAddress: :8880
#paths:
#  cam:
#    source: rpiCamera
#    rpiCameraWidth: 640
#    rpiCameraHeight: 480
#    rpiCameraFPS: 10
#    rpiCameraBitrate: 1000000 # 1 Mb/s
#    rpiCameraIDRPeriod: 1 # Control frame every frame
#    rpiCameraProfile: baseline # No lookahead frames
