import time
import pigpio
from pigpio import pulse

# ---------- hardware / carrier ----------
TX_GPIO = 10
TX_PIN  = 1 << TX_GPIO

# Carrier: 40 kHz ~ 25 µs period. We define the waveforms active‑high.
# A carrier burst drives the pin HIGH for CARRIER_ON_US, then LOW for CARRIER_OFF_US.
# This is later inverted to active‑low (idle high, carrier low).
CARRIER_ON_US  = 12   # pin high (carrier active)
CARRIER_OFF_US = 13   # pin low  (silence)
CYCLE_US       = CARRIER_ON_US + CARRIER_OFF_US   # 25

def carrier_burst(duration_us):
    """
    Return a flat list of pulses toggling TX_PIN at ~40 kHz for
    exactly `duration_us` microseconds. Active‑high (carrier = pin high).
    """
    pulses = []
    remaining = duration_us
    while remaining >= CYCLE_US:
        pulses.append(pulse(TX_PIN, 0, CARRIER_ON_US))   # high
        pulses.append(pulse(0, TX_PIN, CARRIER_OFF_US))  # low
        remaining -= CYCLE_US
    if remaining > 0:
        hi = min(remaining, CARRIER_ON_US)
        pulses.append(pulse(TX_PIN, 0, hi))
        remaining -= hi
        if remaining > 0:
            pulses.append(pulse(0, TX_PIN, remaining))
    return pulses

def invert_pulses(pulses):
    """Swap on/off masks – converts an active‑high waveform to active‑low."""
    return [pulse(p.gpio_off, p.gpio_on, p.delay) for p in pulses]

# ---------- protocol timing ----------
ONE_BIT = 440          # total bit cell (µs)
HALF    = ONE_BIT // 2 # 220
DATA    = 62           # carrier burst length (62.5 µs truncated)
DELAY   = 310          # start‑bit trailing silence (310 µs)  → start total = 62+310 = 372 µs

# ---------- bit patterns (active‑high) ----------
# ONE  = 62 µs HIGH, then 378 µs LOW
ONE  = carrier_burst(DATA) + [pulse(0, TX_PIN, ONE_BIT - DATA)]

# ZERO = 220 µs LOW, 62 µs HIGH, 158 µs LOW
ZERO = [pulse(0, TX_PIN, HALF)] + carrier_burst(DATA) + [pulse(0, TX_PIN, HALF - DATA)]

# START BIT = 62 µs HIGH, then 310 µs LOW
START_BIT = carrier_burst(DATA) + [pulse(0, TX_PIN, DELAY)]

# ---------- PCjr frame (11 bits) ----------
def pcjr_frame(scancode):
    """
    Build one PCjr IR frame (active‑high): start, 8 data LSB first,
    odd parity, stop bit (logic 1). Returns flat pulse list.
    """
    pulses = []
    pulses.extend(START_BIT)

    # data bits 0..7 (LSB first)
    for i in range(8):
        bit = (scancode >> i) & 1
        pulses.extend(ONE if bit else ZERO)

    # odd parity over the 8 data bits
    ones = bin(scancode).count('1')
    parity = 0 if (ones % 2) else 1
    pulses.extend(ONE if parity else ZERO)

    # frame stop bit (always 1)
    pulses.extend(ONE)
    return pulses

# ---------- complete key transmission ----------
def build_waveform(scancode):
    """Return the full transmission: frame + 11 extra stop bits (all ONEs)."""
    return pcjr_frame(scancode) + (ONE * 11)

# ---------- pigpio helpers ----------
def send_waveform(pi, pulses):
    """Load `pulses` into pigpio wave engine and transmit once (blocking)."""
    pi.wave_add_generic(pulses)
    wid = pi.wave_create()
    pi.wave_send_once(wid)
    print(pulses)
    while pi.wave_tx_busy():
        pass
    pi.wave_delete(wid)

def send_key(pi, ch, hold_ms=20):
    """
    Transmit the PCjr make code for character `ch`, wait `hold_ms`,
    then transmit the break code (scancode | 0x80).
    `pi` must be a connected pigpio.pi() instance.
    """
    sc = ord(ch)
    if sc is None:
        raise ValueError(f"No scancode for character: {ch!r}")

    # make code (active‑high -> invert to active‑low)
    send_waveform(pi, invert_pulses(build_waveform(sc)))
    time.sleep(hold_ms / 1000.0)

    # break code (make | 0x80)
    send_waveform(pi, invert_pulses(build_waveform(sc | 0x80)))


if __name__ == "__main__":
    import sys
    pi = pigpio.pi()
    if not pi.connected:
        raise RuntimeError("Could not connect to pigpio daemon")

    for ch in sys.argv[1]:
        send_key(pi, ch)



