import pigpio
from pigpio import pulse

PIN = 3
PIN_MASK = 1 << PIN
LOW_TIME  = 12   # active (pin low)
HIGH_TIME = 13   # idle (pin high)
BURST_MS  = 2    # carrier burst duration
IDLE_MS   = 20   # gap between bursts

# 40 kHz cycles for the burst
cycles = int(BURST_MS * 1000 / (LOW_TIME + HIGH_TIME))
burst = [pulse(0, PIN_MASK, LOW_TIME), pulse(PIN_MASK, 0, HIGH_TIME)] * cycles

# one long idle pulse
idle = [pulse(PIN_MASK, 0, IDLE_MS * 1000)]

wave = burst + idle   # total period: 2 + 20 = 22 ms

pi = pigpio.pi()
pi.set_mode(PIN, pigpio.OUTPUT)
pi.wave_add_generic(wave)
wid = pi.wave_create()

try:
    pi.wave_send_repeat(wid)        # loops forever
    input("Running… Press Enter to stop.\n")
finally:
    pi.wave_tx_stop()
    pi.wave_delete(wid)
    pi.stop()
